import React from 'react';
import {View, Text,  StyleSheet} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialIcons';




const Photo = () => {
  return(
    <View />
  )
}

const styles = StyleSheet.create({});

export default Photo;