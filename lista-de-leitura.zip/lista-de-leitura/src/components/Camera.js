import React , {useState, useEffect} from 'react';
import {View, Text,  StyleSheet, Alert, TouchableOpacity} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialIcons';

import {Camera as ExpoCamera} from 'expo-camera';

const Camera = ({onCloseCamera}) => {
  const [hasPermission, setHasPermission] = useState();
  const [type, setType] =useState(ExpoCamera.Constants.Type.back);

  useEffect(() => {
    (async () => {
      const { status } = await ExpoCamera.requestPermissionsAsync();
      setHasPermission(status === 'grated');
       
    })(); 
  }, []);

  const onFlipPress = () => {
    setType(
      type  === ExpoCamera.Constants.Type.back
        ? ExpoCamera.Constants.Type.front
        : ExpoCamera.Constants.Type.back
    );
  }
  
  return(
    <ExpoCamera 
    style= {{ flex:1 }}
    type={type}>
    
      <View style={styles.actionButtons}>
        <TouchableOpacity onPress={onFlipPress}>
          <Text style={styles.flipText}>
            Flip
          </Text>
        </TouchableOpacity>

        <Icon name="close" size={50} color={"#fff"} onPress={onCloseCamera}/> 
      </View>

      <TouchableOpacity  onPress={() => {}}
          style={styles.takePictureButton} > 
        <Icon name="photo-camera" size={50} color={"#fff"}/>
      </TouchableOpacity>

    </ExpoCamera>
  )
}

const styles = StyleSheet.create({
    actionButtons:{
      justifyContent:"space-between",
      flexDirection:"row",
      marginTop: 10,
      marginRight: 5,
      marginLeft: 5
    },
    flipText:{
      fontSize: 18,
      color: "#fff",
      
    },
    takePictureButton:{
      flex:1,
      justifyContent:"flex-end",
      alignItems:"center",
      marginBottom:5,
    },
});

export default Camera;